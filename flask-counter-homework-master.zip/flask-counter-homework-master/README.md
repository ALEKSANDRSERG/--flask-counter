# Запуск проекта

```bash
docker compose up
```

![](screenshots/terminal.png)
![](screenshots/browser.png)